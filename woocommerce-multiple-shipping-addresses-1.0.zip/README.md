# WooCommerce Multiple Shipping Addresses
## Allow your customer to create multiple shipping addresses, which they can select during checkout.

This is a WordPress plugin, please download the zip file to install it on your WordPress website as a plugin. No warranty provided.